import unittest
# from climbing_robot import ClimbingRobot

class TestClimbingRobot(unittest.TestCase):

    def setUp(self):
        self.robot = ClimbingRobot('Mountain', 'Standard', 100, 1024)

    def test_initialization(self):
        self.assertEqual(self.robot.category, 'Mountain')
        self.assertEqual(self.robot.part_type, 'Standard')
        self.assertEqual(self.robot.capacity, 100)
        self.assertEqual(self.robot.memory, 1024)
        self.assertEqual(self.robot.installed_software, [])

    def test_category_validation(self):
        with self.assertRaises(ValueError):
            ClimbingRobot('Invalid', 'Standard', 100, 1024)

    def test_install_software_success(self):
        software = {'name': 'ClimbingApp', 'capacity_consumption': 20, 'memory_consumption': 100}
        self.assertEqual(self.robot.install_software(software), "Software 'ClimbingApp' successfully installed on Mountain part.")
        self.assertEqual(len(self.robot.installed_software), 1)

    def test_install_software_failure(self):
        software = {'name': 'HeavyApp', 'capacity_consumption': 200, 'memory_consumption': 2048}
        self.assertEqual(self.robot.install_software(software), "Software 'HeavyApp' cannot be installed on Mountain part.")
        self.assertEqual(len(self.robot.installed_software), 0)

    def test_get_used_capacity(self):
        software = {'name': 'ClimbingApp', 'capacity_consumption': 20, 'memory_consumption': 100}
        self.robot.install_software(software)
        self.assertEqual(self.robot.get_used_capacity(), 20)

    def test_get_available_capacity(self):
        software = {'name': 'ClimbingApp', 'capacity_consumption': 20, 'memory_consumption': 100}
        self.robot.install_software(software)
        self.assertEqual(self.robot.get_available_capacity(), 80)

    def test_get_used_memory(self):
        software = {'name': 'ClimbingApp', 'capacity_consumption': 20, 'memory_consumption': 100}
        self.robot.install_software(software)
        self.assertEqual(self.robot.get_used_memory(), 100)

    def test_get_available_memory(self):
        software = {'name': 'ClimbingApp', 'capacity_consumption': 20, 'memory_consumption': 100}
        self.robot.install_software(software)
        self.assertEqual(self.robot.get_available_memory(), 924)

if __name__ == '__main__':
    unittest.main()
