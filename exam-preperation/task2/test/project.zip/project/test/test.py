import unittest
from collections import deque
from project.railway_station import RailwayStation

class TestRailwayStation(unittest.TestCase):
    def test_initialization(self):
        station = RailwayStation("Test Station")
        self.assertEqual(station.name, "Test Station")
        self.assertIsInstance(station.arrival_trains, deque)
        self.assertIsInstance(station.departure_trains, deque)

    def test_set_name(self):
        with self.assertRaises(ValueError):
            RailwayStation("ab")
        station = RailwayStation("Test Station")
        self.assertEqual(station.name, "Test Station")

    def test_new_arrival_on_board(self):
        station = RailwayStation("Test Station")
        station.new_arrival_on_board("Train A")
        self.assertEqual(station.arrival_trains[-1], "Train A")

    def test_train_has_arrived(self):
        station = RailwayStation("Test Station")
        station.new_arrival_on_board("Train A")
        self.assertEqual(station.train_has_arrived("Train A"), "Train A is on the platform and will leave in 5 minutes.")

    def test_train_has_arrived_with_other_trains_before(self):
        station = RailwayStation("Test Station")
        station.new_arrival_on_board("Train B")
        station.new_arrival_on_board("Train A")
        self.assertEqual(station.train_has_arrived("Train A"), "There are other trains to arrive before Train A.")

    def test_train_has_left(self):
        station = RailwayStation("Test Station")
        station.new_arrival_on_board("Train A")
        station.train_has_arrived("Train A")
        self.assertTrue(station.train_has_left("Train A"))

    def test_train_has_left_nonexistent_train(self):
        station = RailwayStation("Test Station")
        station.new_arrival_on_board("Train A")
        self.assertFalse(station.train_has_left("Train B"))

if __name__ == '__main__':
    unittest.main()
