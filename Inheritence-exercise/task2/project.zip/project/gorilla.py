import sys
sys.path.append('C:\\Users\\lifet\\Documents\\GitHub\\Python-OOP\\Inheritence-exercise\\task2\\project')
from project.mammal import Mammal

class Gorilla(Mammal):
    pass