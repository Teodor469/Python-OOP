import sys
sys.path.append('C:\\Users\\lifet\\Documents\\GitHub\\Python-OOP\\Inheritence-exercise\\task2\\project')
from project.reptile import Reptile

class Lizard(Reptile):
    pass