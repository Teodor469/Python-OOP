import sys
sys.path.append('C:\\Users\\lifet\\Documents\\GitHub\\Python-OOP\\Inheritence-exercise\\task2\\project')
from project.animal import Animal

class Reptile(Animal):
    pass