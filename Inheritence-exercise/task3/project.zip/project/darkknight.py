import sys
sys.path.append('C:\\Users\\lifet\\Documents\\GitHub\\Python-OOP\\Inheritence-exercise\\task3\\project')
from project.knight import Knight

class DarkKnight(Knight):
    pass