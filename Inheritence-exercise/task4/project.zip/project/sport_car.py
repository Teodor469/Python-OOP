import sys
sys.path.append('C:\\Users\\lifet\\Documents\\GitHub\\Python-OOP\\Inheritence-exercise\\task4\\project')
from project.car import Car

class SportCar(Car):
    DEFAULT_FUEL_CONSUMPTION = 10