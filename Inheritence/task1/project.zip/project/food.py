class Food:
    def __init__(self, expiration_date) -> None:
        self.expiration_date = expiration_date