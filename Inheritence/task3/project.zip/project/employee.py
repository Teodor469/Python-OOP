import sys
sys.path.append('C:\\Users\\lifet\\Documents\\GitHub\\Python-OOP\\Inheritence\\task3\\project')


class Employee:

    def get_fired(self):
        return "fired..."