import sys
sys.path.append('C:\\Users\\lifet\\Documents\\GitHub\\Python-OOP\\Encapsulation-exercise\\task4\\project')

from project.beverage.beverage import Beverage


class ColdBeverage(Beverage):
    pass