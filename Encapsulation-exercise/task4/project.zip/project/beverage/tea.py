import sys
sys.path.append('C:\\Users\\lifet\\Documents\\GitHub\\Python-OOP\\Encapsulation-exercise\\task4\\project')

from project.beverage.hot_beverage import HotBeverage

class Tea(HotBeverage):
    pass