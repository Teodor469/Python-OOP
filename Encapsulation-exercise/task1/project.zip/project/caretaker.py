import sys
sys.path.append('C:\\Users\\lifet\\Documents\\GitHub\\Python-OOP\\Encapsulation-exercise\\task1\\project')

from project.worker import Worker

class Caretaker(Worker):
    pass